#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
贝叶斯旁路推理模块 — 纯算法实现

提供贝叶斯推理计算功能，作为旁路工具为 LLM 的 prompt 注入概率分析结果。
核心算法来自论文 "Bayesian Teaching Enables Probabilistic Reasoning in LLMs"。
"""

import numpy as np
from itertools import product
from typing import List, Dict, Tuple, Optional


# 特征名称到自然语言描述的映射
FEATURE_NL_MAP = {
    "departure_time": {
        "name": "Departure time",
        "low": "earlier flights",
        "high": "later flights",
    },
    "duration": {
        "name": "Duration",
        "low": "shorter flights",
        "high": "longer flights",
    },
    "number_of_stops": {
        "name": "Number of stops",
        "low": "fewer stops (direct flights)",
        "high": "more stops",
    },
    "price": {
        "name": "Price",
        "low": "cheaper options",
        "high": "more expensive options",
    },
    # 酒店任务的特征
    "distance_to_downtown": {
        "name": "Distance to downtown",
        "low": "closer to downtown",
        "high": "farther from downtown",
    },
    "rating": {
        "name": "Rating",
        "low": "lower rated",
        "high": "higher rated",
    },
    "amenities": {
        "name": "Amenities",
        "low": "fewer amenities",
        "high": "more amenities",
    },
}


class BayesianSidecar:
    """
    贝叶斯旁路推理引擎

    在每轮交互中：
    1. 根据用户的历史选择更新后验分布
    2. 计算推荐和期望效用
    3. 生成自然语言偏好描述
    """

    def __init__(
        self,
        feature_dim: int = 4,
        preference_values: List[float] = None,
        temperature: float = 1.0,
    ):
        if preference_values is None:
            preference_values = [-1, 0, 1]

        self.feature_dim = feature_dim
        self.preference_values = preference_values
        self.temperature = temperature

        # 生成所有可能的偏好函数组合
        self.all_reward_fns = list(product(preference_values, repeat=feature_dim))

        # 预计算偏好矩阵 (n_reward_fns, feature_dim)，向量化核心运算
        self._reward_matrix = np.array(self.all_reward_fns, dtype=np.float64)

        # 初始化均匀先验
        n = len(self.all_reward_fns)
        self.posterior = np.ones(n) / n

    def _utility(self, features: List[float], reward_fn: Tuple) -> float:
        """计算单个选项的效用值"""
        return sum(r * f for r, f in zip(reward_fn, features))

    def _batch_utilities(self, options: List[List[float]]) -> np.ndarray:
        """批量计算所有 (选项, 偏好函数) 的效用矩阵
        返回 shape (n_options, n_reward_fns)"""
        options_matrix = np.array(options, dtype=np.float64)  # (n_options, feature_dim)
        return options_matrix @ self._reward_matrix.T          # (n_options, n_reward_fns)

    def update(self, choice_idx: int, options: List[List[float]]):
        """贝叶斯更新：根据用户选择更新后验分布（向量化版本）"""
        # utilities: (n_options, n_reward_fns)
        utilities = self._batch_utilities(options)
        # 数值稳定的 softmax — 对每个 reward_fn 独立计算
        scaled = utilities / self.temperature              # (n_options, n_reward_fns)
        scaled -= scaled.max(axis=0, keepdims=True)        # 每列减最大值
        exp_u = np.exp(scaled)                             # (n_options, n_reward_fns)
        probs = exp_u / exp_u.sum(axis=0, keepdims=True)   # (n_options, n_reward_fns)
        likelihoods = probs[choice_idx]                    # (n_reward_fns,)

        self.posterior = likelihoods * self.posterior
        total = self.posterior.sum()
        if total > 0:
            self.posterior /= total
        else:
            # 回退到均匀分布（极端情况）
            self.posterior = np.ones(len(self.all_reward_fns)) / len(self.all_reward_fns)

    def recommend(self, options: List[List[float]]) -> int:
        """基于当前后验分布推荐期望效用最高的选项"""
        eus = self.get_expected_utilities(options)
        return int(np.argmax(eus))

    def get_expected_utilities(self, options: List[List[float]]) -> List[float]:
        """计算每个选项的期望效用（向量化版本）"""
        # utilities: (n_options, n_reward_fns)
        utilities = self._batch_utilities(options)
        # 后验加权求和: (n_options,)
        eus = utilities @ self.posterior
        return eus.tolist()

    def get_top_beliefs(self, n: int = 3) -> List[Dict]:
        """返回后验概率最高的 n 个偏好函数"""
        top_indices = np.argsort(self.posterior)[-n:][::-1]
        return [
            {
                "reward_fn": self.all_reward_fns[i],
                "prob": float(self.posterior[i]),
            }
            for i in top_indices
        ]

    def get_map_preference(self) -> Tuple:
        """返回 MAP（最大后验概率）偏好函数"""
        return self.all_reward_fns[int(np.argmax(self.posterior))]

    def get_confidence(self) -> float:
        """返回当前推荐的置信度（MAP 偏好的后验概率）"""
        return float(np.max(self.posterior))

    def get_weighted_preference(self) -> List[float]:
        """返回后验加权的偏好向量（向量化版本）"""
        # _reward_matrix: (n_reward_fns, feature_dim), posterior: (n_reward_fns,)
        weighted = self.posterior @ self._reward_matrix  # (feature_dim,)
        return weighted.tolist()

    def get_nl_preference(self, features: List[str]) -> str:
        """生成自然语言偏好描述"""
        weighted_pref = self.get_weighted_preference()
        lines = []
        lines.append("Based on the user's choice history, here is a preference profile:")

        for feat_name, weight in zip(features, weighted_pref):
            feat_info = FEATURE_NL_MAP.get(feat_name, {
                "name": feat_name.replace("_", " ").title(),
                "low": f"lower {feat_name}",
                "high": f"higher {feat_name}",
            })

            abs_w = abs(weight)
            if abs_w > 0.7:
                strength = "strong"
            elif abs_w > 0.3:
                strength = "moderate"
            else:
                strength = "weak/no clear"

            if abs_w <= 0.1:
                direction = "no clear preference"
                lines.append(f"- {feat_info['name']}: {direction}")
            else:
                direction = feat_info["low"] if weight < 0 else feat_info["high"]
                lines.append(f"- {feat_info['name']}: Prefers {direction} ({strength} preference)")

        return "\n".join(lines)

    def reset(self):
        """重置为均匀先验"""
        n = len(self.all_reward_fns)
        self.posterior = np.ones(n) / n

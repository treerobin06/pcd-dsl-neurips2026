#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Prompt 注入策略模块

提供 13 种 prompt 策略，用于消融实验。
Phase 2: 6 种外部算法注入策略（含 random_rec 控制组）
COT 补充: 7 种 COT/few-shot/tool-use/混合策略
"""

from typing import Dict, Any


class PromptInjector:
    """管理不同的 prompt 注入策略"""

    STRATEGIES = [
        # Phase 2: 外部算法注入
        "baseline", "direct_rec", "nl_preference", "nl_pref_rec", "full_math", "random_rec",
        # COT 补充实验
        "cot_reflect", "cot_bayesian", "few_shot",
        "tool_use", "cot_then_math", "cot_self_consistency", "math_then_cot",
        # Tool Calling 内容消融
        "tool_direct_rec", "tool_nl_pref", "tool_nl_pref_rec", "tool_random_rec", "tool_empty",
        # 消息格式消融（实验 5：信任梯度）
        "system_inject", "user_separate", "assistant_inject", "fake_tool",
        # 实验 5b：位置 × 内容交叉消融
        "user_separate_rec",
    ]

    @staticmethod
    def _entity(info: Dict) -> str:
        """从 bayes_info 中获取实体名称，默认 Flight"""
        return info.get("entity_name", "Flight")

    @staticmethod
    def _features_str(info: Dict) -> str:
        """从 bayes_info 中获取特征列表字符串"""
        features = info.get("features", [])
        if features:
            return ", ".join(features)
        return "departure_time, duration, number_of_stops, price"

    def inject(self, strategy: str, original_prompt: str, bayes_info: Dict[str, Any]) -> str:
        """
        根据策略将贝叶斯分析结果注入 prompt

        Args:
            strategy: 策略名称
            original_prompt: 原始 prompt
            bayes_info: 贝叶斯分析信息，包含:
                - recommendation (int): 推荐选项索引 (0-based)
                - nl_preference (str): 自然语言偏好描述
                - top_beliefs (list): 后验概率最高的偏好函数
                - expected_utilities (list): 各选项的期望效用
                - confidence (float): 置信度
                - entity_name (str): 实体名称（Flight/Hotel 等）
                - features (list): 特征名称列表

        Returns:
            增强后的 prompt
        """
        if strategy == "baseline":
            return original_prompt
        elif strategy == "direct_rec":
            return self._inject_direct_rec(original_prompt, bayes_info)
        elif strategy == "nl_preference":
            return self._inject_nl_preference(original_prompt, bayes_info)
        elif strategy == "nl_pref_rec":
            return self._inject_nl_pref_rec(original_prompt, bayes_info)
        elif strategy == "full_math":
            return self._inject_full_math(original_prompt, bayes_info)
        elif strategy == "random_rec":
            return self._inject_random_rec(original_prompt, bayes_info)
        # COT 补充实验
        elif strategy == "cot_reflect":
            return self._inject_cot_reflect(original_prompt, bayes_info)
        elif strategy == "cot_bayesian":
            return self._inject_cot_bayesian(original_prompt, bayes_info)
        elif strategy == "few_shot":
            return self._inject_few_shot(original_prompt, bayes_info)
        elif strategy == "cot_self_consistency":
            return self._inject_cot_reflect(original_prompt, bayes_info)  # 复用 cot_reflect 的 prompt
        elif strategy == "math_then_cot":
            return self._inject_math_then_cot(original_prompt, bayes_info)
        # 多轮策略的第一轮 prompt 在 Runner 中处理
        elif strategy in ("tool_use", "cot_then_math",
                          "tool_direct_rec", "tool_nl_pref", "tool_nl_pref_rec",
                          "tool_random_rec", "tool_empty",
                          # 消息格式消融（实验 5）
                          "system_inject", "user_separate", "assistant_inject", "fake_tool",
                          "user_separate_rec"):
            return original_prompt  # 第一轮不注入，由 Runner 的多轮逻辑处理
        else:
            raise ValueError(f"未知策略: {strategy}")

    def _inject_direct_rec(self, prompt: str, info: Dict) -> str:
        entity = self._entity(info)
        rec = info.get("recommendation", 0)
        option_num = rec + 1
        return (
            f"{prompt}\n\n"
            f"Note: A mathematical Bayesian analysis suggests {entity} {option_num} "
            f"is the best option for this user. Consider this alongside your own reasoning."
        )

    def _inject_nl_preference(self, prompt: str, info: Dict) -> str:
        nl_pref = info.get("nl_preference", "")
        return f"{prompt}\n\n{nl_pref}"

    def _inject_nl_pref_rec(self, prompt: str, info: Dict) -> str:
        entity = self._entity(info)
        nl_pref = info.get("nl_preference", "")
        rec = info.get("recommendation", 0)
        option_num = rec + 1
        return (
            f"{prompt}\n\n{nl_pref}\n\n"
            f"Recommended: {entity} {option_num} best matches this preference profile."
        )

    def _inject_random_rec(self, prompt: str, info: Dict) -> str:
        """随机推荐控制组 — 格式与 direct_rec 完全相同，但推荐是随机的"""
        entity = self._entity(info)
        rec = info.get("recommendation", 0)  # 调用方已传入随机值
        option_num = rec + 1
        return (
            f"{prompt}\n\n"
            f"Note: A mathematical Bayesian analysis suggests {entity} {option_num} "
            f"is the best option for this user. Consider this alongside your own reasoning."
        )

    # ==========================================
    # COT 补充实验策略
    # ==========================================
    def _inject_cot_reflect(self, prompt: str, info: Dict) -> str:
        """简单反思提示 — 要求 LLM 先分析再选择"""
        entity = self._entity(info)
        features_str = self._features_str(info)
        return (
            f"{prompt}\n\n"
            "Before making your choice, think step by step:\n"
            "1. What patterns have you noticed in the user's previous choices?\n"
            f"2. What features ({features_str}) seem most important to them?\n"
            f"3. Based on this analysis, which {entity.lower()} best matches their preferences?\n\n"
            f'Show your reasoning, then state your final choice as "{entity} X".'
        )

    def _inject_cot_bayesian(self, prompt: str, info: Dict) -> str:
        """教贝叶斯推理概念 — 教方法但不给计算结果"""
        entity = self._entity(info)
        features = info.get("features", [])
        features_str = self._features_str(info)
        n_features = len(features) if features else 4
        n_vals = len(info.get("preference_values", [-1, 0, 1]))
        n_combos = n_vals ** n_features
        return (
            f"{prompt}\n\n"
            "You should reason about the user's preferences using Bayesian thinking:\n"
            f"- Consider each feature: {features_str}\n"
            "- For each feature, the user's preference weight could be: "
            "-1 (prefers lower/earlier/fewer), 0 (doesn't care), or +1 (prefers higher/later/more)\n"
            f"- There are {n_combos} possible preference weight combinations\n"
            f"- Based on which {entity.lower()}s the user chose in previous rounds, "
            "eliminate weight combinations that are inconsistent with their choices\n"
            f"- For the remaining likely combinations, compute which {entity.lower()} has the best expected score\n\n"
            f'Show your step-by-step reasoning, then state your final choice as "{entity} X".'
        )

    def _inject_few_shot(self, prompt: str, info: Dict) -> str:
        """范例学习 — 在 prompt 前插入 few-shot 范例"""
        examples = info.get("few_shot_examples", "")
        return f"{examples}\n\nNow help this new user:\n\n{prompt}"

    def _inject_math_then_cot(self, prompt: str, info: Dict) -> str:
        """先展示 full_math 结果，再要求批判性思考"""
        entity = self._entity(info)
        # 复用 full_math 的注入内容
        math_prompt = self._inject_full_math(prompt, info)
        return (
            f"{math_prompt}\n\n"
            "Before giving your final answer, critically evaluate this analysis:\n"
            "1. Does the Bayesian recommendation make sense given what you've observed about the user?\n"
            "2. Are there any patterns the mathematical analysis might have missed?\n"
            f'3. State your final choice as "{entity} X" with your reasoning.'
        )

    # ==========================================
    # Phase 2 外部算法注入策略
    # ==========================================
    def _inject_full_math(self, prompt: str, info: Dict) -> str:
        entity = self._entity(info)
        top_beliefs = info.get("top_beliefs", [])
        eus = info.get("expected_utilities", [])
        rec = info.get("recommendation", 0)
        option_num = rec + 1

        lines = [prompt, "", "--- Bayesian Analysis Report ---"]

        if top_beliefs:
            lines.append("Current belief about user preferences (top candidates):")
            for i, belief in enumerate(top_beliefs, 1):
                rf = belief["reward_fn"]
                prob = belief["prob"] * 100
                lines.append(f"{i}. {rf} (prob: {prob:.1f}%)")

        if eus:
            lines.append("")
            lines.append("Expected utility for each option:")
            for i, eu in enumerate(eus):
                lines.append(f"- {entity} {i + 1}: {eu:.3f}")

        lines.append("")
        lines.append(f"Bayesian recommendation: {entity} {option_num}")
        lines.append("--- End of Analysis ---")

        return "\n".join(lines)

    def format_math_report(self, info: Dict) -> str:
        """生成纯数学分析报告文本（不含原始 prompt，供多轮策略使用）"""
        return self._inject_full_math("", info).lstrip("\n")

    def format_tool_response(self, strategy: str, info: Dict) -> str:
        """根据 tool_* 策略名生成工具返回内容（不含原始 prompt）"""
        entity = self._entity(info)
        if strategy == "tool_use":
            # 完整数学分析（复用已有方法）
            return self.format_math_report(info)
        elif strategy == "tool_direct_rec":
            rec = info.get("recommendation", 0)
            return (
                f"Bayesian analysis suggests {entity} {rec + 1} "
                f"is the best option for this user."
            )
        elif strategy == "tool_nl_pref":
            return info.get("nl_preference", "No preference data available.")
        elif strategy == "tool_nl_pref_rec":
            nl_pref = info.get("nl_preference", "")
            rec = info.get("recommendation", 0)
            return (
                f"{nl_pref}\n\n"
                f"Recommended: {entity} {rec + 1} best matches this preference profile."
            )
        elif strategy == "tool_random_rec":
            rec = info.get("recommendation", 0)  # 调用方已传入随机值
            return (
                f"Bayesian analysis suggests {entity} {rec + 1} "
                f"is the best option for this user."
            )
        elif strategy == "tool_empty":
            return (
                "Analysis complete. Insufficient data to provide "
                "a confident recommendation at this time."
            )
        else:
            # 兜底：返回完整数学分析
            return self.format_math_report(info)

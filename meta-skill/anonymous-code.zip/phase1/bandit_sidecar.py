#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
多臂赌博机贝叶斯旁路模块 — Beta-Bernoulli 共轭更新

为 TextBandit 任务提供精确贝叶斯推断，计算每臂的后验胜率估计。
"""

import numpy as np
from typing import List, Dict, Optional


# TextBandit 论文中的 4 种臂配置（真实胜率）
BANDIT_CONFIGS = {
    2: {"probs": [0.30, 0.65], "best": 1},
    3: {"probs": [0.40, 0.30, 0.70], "best": 2},
    4: {"probs": [0.80, 0.60, 0.35, 0.25], "best": 0},
    5: {"probs": [0.20, 0.75, 0.35, 0.25, 0.55], "best": 1},
}


class BanditSidecar:
    """Beta-Bernoulli 贝叶斯旁路引擎（多臂赌博机）"""

    def __init__(self, n_arms: int):
        self.n_arms = n_arms
        # Beta(1,1) = 均匀先验
        self.alpha = np.ones(n_arms)
        self.beta_params = np.ones(n_arms)

    def update(self, arm: int, reward: int):
        """观察到 arm 的 reward (0/1) 后更新后验

        Args:
            arm: 0-indexed 臂编号
            reward: 1=赢, 0=输
        """
        self.alpha[arm] += reward
        self.beta_params[arm] += (1 - reward)

    def recommend(self) -> int:
        """返回后验均值最高的臂 (0-indexed)"""
        means = self.alpha / (self.alpha + self.beta_params)
        return int(np.argmax(means))

    def thompson_sample(self) -> int:
        """Thompson Sampling: 从后验采样，选采样值最高的臂"""
        samples = np.array([
            np.random.beta(self.alpha[i], self.beta_params[i])
            for i in range(self.n_arms)
        ])
        return int(np.argmax(samples))

    def get_posterior_means(self) -> np.ndarray:
        """返回所有臂的后验均值"""
        return self.alpha / (self.alpha + self.beta_params)

    def get_analysis_text(self) -> str:
        """生成自然语言分析报告（用于 prompt 注入）"""
        means = self.get_posterior_means()
        rec = self.recommend()

        lines = ["--- Bayesian Analysis Report ---"]
        lines.append("Estimated win probability for each machine (Beta-Bernoulli posterior):")
        for i in range(self.n_arms):
            wins = int(self.alpha[i] - 1)
            losses = int(self.beta_params[i] - 1)
            total = wins + losses
            lines.append(
                f"  Machine {i+1}: {means[i]*100:.1f}% "
                f"(wins: {wins}, losses: {losses}, total plays: {total})"
            )
        lines.append("")
        lines.append(f"Bayesian recommendation: Machine {rec + 1}")
        lines.append("--- End of Analysis ---")
        return "\n".join(lines)

    def get_short_rec_text(self) -> str:
        """简短推荐文本"""
        rec = self.recommend()
        means = self.get_posterior_means()
        return (
            f"Bayesian analysis suggests Machine {rec + 1} "
            f"(estimated {means[rec]*100:.1f}% win rate) is the best choice."
        )

    def reset(self):
        """重置后验到先验"""
        self.alpha = np.ones(self.n_arms)
        self.beta_params = np.ones(self.n_arms)


def simulate_bandit(arm: int, probs: List[float]) -> int:
    """模拟赌博机，返回 1(赢) 或 0(输)"""
    return 1 if np.random.random() < probs[arm] else 0

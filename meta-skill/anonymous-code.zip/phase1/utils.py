#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
公共工具模块

提供评估数据加载、Prompt 构造和航班选择解析等公共函数，
供 run_sidecar_experiment.py 和 run_benchmark_parallel.py 复用。
"""

import re
import json
from typing import List, Dict


def load_eval_data(file_path: str, max_samples: int = None) -> List[Dict]:
    """加载评估数据"""
    data = []
    with open(file_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                data.append(json.loads(line))
                if max_samples and len(data) >= max_samples:
                    break
    return data


def detect_entity_name(options: List[str]) -> str:
    """从选项文本中自动检测实体名称（Flight/Hotel/Product/Machine 等）"""
    if not options:
        return "Option"
    first = options[0].strip()
    # 格式: "Flight 1: ..." 或 "Hotel 1: ..."
    m = re.match(r'^([A-Za-z]+)\s+\d+', first)
    if m:
        return m.group(1)
    return "Option"


def format_round_prompt(options: List[str], history: List[Dict] = None, entity: str = None) -> str:
    """构造原始 prompt（支持多种实体类型）

    Args:
        options: 当前轮的选项列表
        history: 历史交互记录
        entity: 实体名称（如 "Flight"/"Hotel"），None 则自动检测
    """
    if entity is None:
        entity = detect_entity_name(options)
    entity_lower = entity.lower()
    entity_plural = entity_lower + "s"

    system_prompt = (
        f"Help me select the best {entity_plural} for my needs. I have specific preferences "
        f"for what I like and dislike in a {entity_lower}, and these preferences remain the same. "
        f"You need to figure out my preferences and select the best {entity_plural} for me. "
        "Use your best judgment if you are unsure. Do not say you need more information."
    )
    question = f"Which {entity_lower} is the best option?"

    parts = []
    if not history:
        parts.append(system_prompt)
        parts.append("")
        parts.append(question)
        parts.append("")
        for opt in options:
            parts.append(opt)
    else:
        parts.append(system_prompt)
        parts.append("")
        parts.append(question)
        parts.append("")
        for opt in history[0]["options"]:
            parts.append(opt)
        for i, h in enumerate(history):
            if h["correct"]:
                feedback = f"Your option {entity} {h['prediction'] + 1} is correct."
            else:
                feedback = (
                    f"Your option {entity} {h['prediction'] + 1} is incorrect. "
                    f"I prefer {entity} {h['user_choice'] + 1}."
                )
            parts.append("")
            parts.append(feedback)
            if i < len(history) - 1:
                parts.append("")
                parts.append(question)
                parts.append("")
                for opt in history[i + 1]["options"]:
                    parts.append(opt)
        parts.append("")
        parts.append(question)
        parts.append("")
        for opt in options:
            parts.append(opt)
    return "\n".join(parts)


def build_few_shot_examples() -> str:
    """构建 few-shot 范例文本（2 个用户 × 2 轮，展示偏好推理过程）"""
    return (
        "Here are examples of how to analyze user preferences from their flight choices:\n\n"
        "=== Example 1 ===\n"
        "A user is choosing flights. Let's track their preferences.\n\n"
        "Round 1 options:\n"
        "Flight 1: departure time: 02:00 PM, duration: 30 min, number of stops: 1, price: $370\n"
        "Flight 2: departure time: 02:00 PM, duration: 4 hr 24 min, number of stops: 0, price: $730\n"
        "Flight 3: departure time: 03:36 PM, duration: 16 hr 6 min, number of stops: 0, price: $1000\n"
        "User chose: Flight 1\n"
        "Analysis: Flight 1 has the shortest duration (30 min) and lowest price ($370). "
        "The user likely prefers shorter, cheaper flights.\n\n"
        "Round 2 options:\n"
        "Flight 1: departure time: 10:00 PM, duration: 4 hr 24 min, number of stops: 2, price: $190\n"
        "Flight 2: departure time: 10:48 AM, duration: 16 hr 6 min, number of stops: 0, price: $730\n"
        "Flight 3: departure time: 10:48 AM, duration: 16 hr 6 min, number of stops: 2, price: $460\n"
        "User chose: Flight 2\n"
        "Analysis: Interesting - Flight 1 was cheapest but the user chose Flight 2. "
        "Flight 2 departs earlier (10:48 AM vs 10:00 PM) and has 0 stops. "
        "The user seems to also strongly prefer earlier departures and fewer stops, "
        "not just low price. Updating preferences: prefers earlier, shorter, fewer stops, cheaper.\n\n"
        "=== Example 2 ===\n"
        "A different user with different preferences.\n\n"
        "Round 1 options:\n"
        "Flight 1: departure time: 02:00 PM, duration: 10 hr 15 min, number of stops: 1, price: $910\n"
        "Flight 2: departure time: 12:24 PM, duration: 12 hr 12 min, number of stops: 1, price: $550\n"
        "Flight 3: departure time: 07:36 AM, duration: 6 hr 21 min, number of stops: 1, price: $370\n"
        "User chose: Flight 2\n"
        "Analysis: Flight 3 was cheapest and shortest, but user chose Flight 2 (mid-price, later departure). "
        "The user may value later departure time over price.\n\n"
        "Round 2 options:\n"
        "Flight 1: departure time: 05:12 PM, duration: 10 hr 15 min, number of stops: 0, price: $1000\n"
        "Flight 2: departure time: 09:12 AM, duration: 30 min, number of stops: 1, price: $820\n"
        "Flight 3: departure time: 05:12 PM, duration: 2 hr 27 min, number of stops: 1, price: $190\n"
        "User chose: Flight 3\n"
        "Analysis: Flight 3 has a late departure (5:12 PM) AND is the cheapest ($190). "
        "Confirmed: this user prefers later departures and lower prices. "
        "For the next round, pick the flight with the latest departure and lowest price.\n"
    )


def extract_choice(response: str, entity: str = "Flight", n_options: int = 3) -> int:
    """从模型响应中提取选择（返回 0-indexed 或 -1）

    支持多种实体类型：Flight/Hotel/Machine/Option 等。
    策略：先用高置信度模式匹配最后出现的结论性语句，再逐步降级。
    优先匹配靠后的内容（模型通常先分析、后给结论）。
    """
    if not response or not response.strip():
        return -1

    # 去除 markdown 加粗/斜体标记，统一处理
    cleaned = re.sub(r'\*+', '', response)
    text = cleaned.lower().strip()
    entity_lower = entity.lower()

    # 第一优先级：明确的结论性语句（从后往前搜索）
    conclusion_patterns = [
        rf"the best option is {entity_lower}\s*(\d+)",
        rf"{entity_lower}\s*(\d+)\s*is the best",
        rf"i (?:would )?(?:recommend|choose|select|suggest)\s*{entity_lower}\s*(\d+)",
        rf"(?:best|optimal|top) (?:option|choice|pick) is {entity_lower}\s*(\d+)",
        rf"(?:my |the )?(?:answer|choice|recommendation|pick) is {entity_lower}\s*(\d+)",
        rf"(?:go with|pick|select) {entity_lower}\s*(\d+)",
    ]
    for pattern in conclusion_patterns:
        matches = re.findall(pattern, text)
        if matches:
            num = int(matches[-1])
            if 1 <= num <= n_options:
                return num - 1

    # 第二优先级：独立成行或句首的 "Entity X"
    line_patterns = [
        rf"^{entity_lower}\s*(\d+)\s*[.\n]",
        rf"\b{entity_lower}\s*(\d+)\s*[.!]\s*$",
    ]
    for pattern in line_patterns:
        matches = re.findall(pattern, text, re.MULTILINE)
        if matches:
            num = int(matches[-1])
            if 1 <= num <= n_options:
                return num - 1

    # 第三优先级：通用 "entity X" 匹配（取最后一个）
    matches = re.findall(rf"\b{entity_lower}\s*(\d+)\b", text)
    if matches:
        valid = [int(m) for m in matches if 1 <= int(m) <= n_options]
        if valid:
            return valid[-1] - 1

    # 第四优先级："option X"（取最后一个）
    matches = re.findall(r"\boption\s*(\d+)\b", text)
    if matches:
        valid = [int(m) for m in matches if 1 <= int(m) <= n_options]
        if valid:
            return valid[-1] - 1

    return -1


def extract_flight_choice(response: str) -> int:
    """向后兼容：从模型响应中提取航班选择"""
    return extract_choice(response, entity="Flight", n_options=3)

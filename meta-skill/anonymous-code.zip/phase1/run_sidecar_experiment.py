#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
贝叶斯旁路注入实验脚本（asyncio 版本）

使用 asyncio + AsyncOpenAI 实现高并发 API 调用，避免线程池死锁问题。
每轮交互前先运行 BayesianSidecar 计算后验分布和推荐，然后注入到 prompt 中。

用法:
  # 快速验证（50 样本，1 个模型，1 种策略）
  python run_sidecar_experiment.py -n 50 -m openai/gpt-4o-mini --strategies direct_rec

  # 跑所有策略
  python run_sidecar_experiment.py -n 50 -m openai/gpt-4o-mini --strategies all

  # 全量实验（多模型 × 多策略并行）
  python run_sidecar_experiment.py -m openai/gpt-4o openai/gpt-4o-mini openai/gpt-4.1-nano --strategies all

  # 列出所有策略
  python run_sidecar_experiment.py --list-strategies
"""

import os
import sys
import json
import time
import random
import argparse
import asyncio
import tempfile
from datetime import datetime
from typing import List, Dict, Tuple, Optional
from collections import defaultdict
import traceback
import numpy as np

# 修复 Windows 控制台编码
if sys.platform == "win32":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    sys.stderr.reconfigure(encoding="utf-8", errors="replace")

import httpx
from openai import AsyncOpenAI
from bayesian_sidecar import BayesianSidecar
from prompt_injector import PromptInjector
from utils import load_eval_data, format_round_prompt, extract_choice, detect_entity_name, build_few_shot_examples


# ==========================================
# 基础组件
# ==========================================
class CheckpointManager:
    """断点续传管理"""
    def __init__(self, checkpoint_dir: str):
        self.checkpoint_dir = checkpoint_dir
        os.makedirs(checkpoint_dir, exist_ok=True)
        self.completed_file = os.path.join(checkpoint_dir, "completed.json")
        self.completed = self._load()

    def _load(self) -> dict:
        if os.path.exists(self.completed_file):
            with open(self.completed_file, "r", encoding="utf-8") as f:
                return json.load(f)
        return {}

    def is_completed(self, label: str) -> bool:
        return label in self.completed

    def mark_completed(self, label: str, result: dict):
        self.completed[label] = {
            "completed_at": datetime.now().isoformat(),
            "overall_accuracy": result.get("overall_accuracy", 0),
        }
        # 安全写入：先写临时文件再 rename，防止断电时丢失数据
        fd, tmp_path = tempfile.mkstemp(
            dir=self.checkpoint_dir, suffix=".tmp"
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(self.completed, f, indent=2, ensure_ascii=False)
            os.replace(tmp_path, self.completed_file)
        except Exception:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise

    def get_completed_result(self, label: str) -> Optional[dict]:
        result_file = os.path.join(
            self.checkpoint_dir, "..", "sidecar_results", f"{label}.json"
        )
        if os.path.exists(result_file):
            with open(result_file, "r", encoding="utf-8") as f:
                return json.load(f)
        return None


# ==========================================
# 统计工具
# ==========================================
def compute_bootstrap_ci(correct_flags, n_bootstrap=2000, ci=0.95):
    """对 0/1 列表计算 Bootstrap 95% 置信区间"""
    arr = np.array(correct_flags, dtype=float)
    if len(arr) == 0:
        return {"mean": 0.0, "ci_lower": 0.0, "ci_upper": 0.0}
    rng = np.random.default_rng(42)
    boot_means = [
        np.mean(rng.choice(arr, size=len(arr), replace=True))
        for _ in range(n_bootstrap)
    ]
    alpha = (1 - ci) / 2
    return {
        "mean": float(arr.mean()),
        "ci_lower": float(np.percentile(boot_means, alpha * 100)),
        "ci_upper": float(np.percentile(boot_means, (1 - alpha) * 100)),
    }


# ==========================================
# 异步旁路注入实验运行器
# ==========================================
NO_TEMP_KEYWORDS = ["o3", "o1", "o4", "deepseek-r1"]


class AsyncSidecarRunner:
    """单个 模型×策略 组合的异步实验运行器"""

    OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1"

    def __init__(
        self,
        model_id: str,
        strategy: str,
        semaphore: asyncio.Semaphore,
        client: "AsyncOpenAI",
        temperature: float = 0.0,
        round_only: int = None,
        entity_name: str = "Flight",
        n_options: int = 3,
        preference_values: List[float] = None,
    ):
        self.model_id = model_id
        self.strategy = strategy
        self.semaphore = semaphore  # 同模型的所有策略共享同一个 semaphore
        self.round_only = round_only  # 仅跑指定轮次（0-indexed），None 表示跑全部 5 轮
        self.temperature = temperature
        self.injector = PromptInjector()
        self.run_label = f"{model_id.replace('/', '__')}__sidecar_{strategy}"
        self.client = client  # 同模型共享同一个 client
        self.entity_name = entity_name
        self.n_options = n_options
        self.preference_values = preference_values  # None 表示使用 BayesianSidecar 默认值

    def _should_skip_temp(self) -> bool:
        name_lower = self.model_id.lower()
        return any(kw in name_lower for kw in NO_TEMP_KEYWORDS)

    async def _generate_single(self, prompt: str, idx: int = 0) -> Tuple[int, str, bool]:
        """单个异步 API 请求（带重试 + 随机抖动），返回 (idx, text, is_fallback)"""
        max_retries = 5
        for attempt in range(max_retries):
            try:
                async with self.semaphore:
                    api_params = {
                        "model": self.model_id,
                        "messages": [{"role": "user", "content": prompt}],
                        "max_tokens": 8192,
                    }
                    if not self._should_skip_temp():
                        api_params["temperature"] = self.temperature
                    # stop 独立于 temperature，避免 o1/o3 等模型缺失 stop
                    api_params["stop"] = ["Question:", "User:"]

                    response = await self.client.chat.completions.create(**api_params)
                    if not response or not response.choices:
                        raise ValueError("API 返回空响应")
                    text = response.choices[0].message.content

                    if not text or not text.strip():
                        return (idx, f"{self.entity_name} 1", True)  # 空响应标记为 fallback
                    return (idx, text.strip(), False)
            except Exception as e:
                if attempt < max_retries - 1:
                    is_rate = "429" in str(e) or "rate" in str(e).lower()

                    base_wait = (10 + 5 * attempt) if is_rate else 2 ** (attempt + 1)
                    # 随机抖动 ±50% 避免 thundering herd
                    jitter = base_wait * (0.5 + random.random())
                    if attempt == 0:
                        # 只在首次重试时打印，避免刷屏
                        print(
                            f"      [{self.run_label[:40]}] "
                            f"样本{idx} 重试 {attempt+1}/{max_retries}: {str(e)[:60]}",
                            flush=True,
                        )
                    await asyncio.sleep(jitter)
                else:
                    print(
                        f"      [{self.run_label[:40]}] 样本 {idx} 最终失败",
                        flush=True,
                    )
                    return (idx, f"{self.entity_name} 1", True)
        return (idx, f"{self.entity_name} 1", True)

    async def _generate_with_params(self, prompt: str, idx: int, max_tokens: int = 128,
                                     temperature: float = None, stop=None) -> Tuple[int, str, bool]:
        """通用生成方法，支持自定义 max_tokens/temperature/stop"""
        max_retries = 5
        temp = temperature if temperature is not None else self.temperature
        for attempt in range(max_retries):
            try:
                async with self.semaphore:
                    api_params = {
                        "model": self.model_id,
                        "messages": [{"role": "user", "content": prompt}],
                        "max_tokens": max_tokens,
                    }
                    if not self._should_skip_temp():
                        api_params["temperature"] = temp
                        if stop is not None:
                            api_params["stop"] = stop
                    response = await self.client.chat.completions.create(**api_params)
                    if not response or not response.choices:
                        raise ValueError("API 返回空响应")
                    text = response.choices[0].message.content
                    return (idx, text.strip() if text else f"{self.entity_name} 1", False)
            except Exception as e:
                if attempt < max_retries - 1:
                    is_rate = "429" in str(e) or "rate" in str(e).lower()

                    base_wait = (10 + 5 * attempt) if is_rate else 2 ** (attempt + 1)
                    jitter = base_wait * (0.5 + random.random())
                    await asyncio.sleep(jitter)
                else:
                    return (idx, f"{self.entity_name} 1", True)
        return (idx, f"{self.entity_name} 1", True)

    async def _generate_tool_use(self, prompt: str, bayes_info: dict, idx: int) -> Tuple[int, str, bool, bool]:
        """tool_use 策略：function calling，返回 (idx, text, is_fallback, tool_called)"""
        tools = [{
            "type": "function",
            "function": {
                "name": "bayesian_analyze",
                "description": "Run Bayesian inference to analyze the user's preference weights based on their past choices. Returns the most likely preference weights, expected utility for each option, and a recommendation.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "reason": {"type": "string", "description": "Why you want to run this analysis"}
                    },
                    "required": ["reason"]
                }
            }
        }]
        max_retries = 3
        msg = None  # 缓存第一步结果，避免重试时浪费 API
        for attempt in range(max_retries):
            try:
                if msg is None:
                    async with self.semaphore:
                        # 第一轮：带 tools 定义
                        api_params = {
                            "model": self.model_id,
                            "messages": [{"role": "user", "content": prompt}],
                            "tools": tools,
                            "max_tokens": 256,
                        }
                        if not self._should_skip_temp():
                            api_params["temperature"] = self.temperature
                        response1 = await self.client.chat.completions.create(**api_params)
                        if not response1 or not response1.choices:
                            raise ValueError("API 返回空响应")
                        msg = response1.choices[0].message

                # 检查是否调用了工具
                if msg.tool_calls:
                    tool_call = msg.tool_calls[0]
                    tool_result = self.injector.format_tool_response(self.strategy, bayes_info)
                    messages = [
                        {"role": "user", "content": prompt},
                        msg,
                        {"role": "tool", "tool_call_id": tool_call.id, "content": tool_result},
                    ]
                    async with self.semaphore:
                        response2 = await self.client.chat.completions.create(
                            model=self.model_id, messages=messages, max_tokens=128
                        )
                    text = response2.choices[0].message.content
                    return (idx, text.strip() if text else f"{self.entity_name} 1", False, True)
                else:
                    text = msg.content
                    return (idx, text.strip() if text else f"{self.entity_name} 1", False, False)
            except Exception as e:
                if attempt < max_retries - 1:
                    is_rate = "429" in str(e) or "rate" in str(e).lower()
                    base_wait = (10 + 5 * attempt) if is_rate else 2 ** (attempt + 1)
                    await asyncio.sleep(base_wait * (0.5 + random.random()))
                else:
                    return (idx, f"{self.entity_name} 1", True, False)
        return (idx, f"{self.entity_name} 1", True, False)

    async def _generate_cot_then_math(self, prompt: str, bayes_info: dict, idx: int) -> Tuple[int, str, bool]:
        """两步对话：先 COT 推理，再展示 full_math 综合判断"""
        max_retries = 3
        cot_text = None  # 缓存第一步结果，重试只重跑第二步
        cot_prompt = (
            f"{prompt}\n\n"
            "Before making your choice, first analyze what you think the user's preferences are "
            "based on their past choices. Write down your analysis."
        )
        for attempt in range(max_retries):
            try:
                # 第一轮：COT 推理（仅在首次执行）
                if cot_text is None:
                    async with self.semaphore:
                        r1 = await self.client.chat.completions.create(
                            model=self.model_id,
                            messages=[{"role": "user", "content": cot_prompt}],
                            max_tokens=512,
                        )
                    cot_text = r1.choices[0].message.content or ""
                # 第二轮：展示 full_math 结果，综合判断
                math_content = self.injector.format_math_report(bayes_info)
                messages = [
                    {"role": "user", "content": cot_prompt},
                    {"role": "assistant", "content": cot_text},
                    {"role": "user", "content": (
                        f"Now consider this mathematical Bayesian analysis:\n\n{math_content}\n\n"
                        "Combining your own reasoning with this analysis, "
                        f'which {self.entity_name.lower()} is the best choice? State your final answer as "{self.entity_name} X".'
                    )},
                ]
                async with self.semaphore:
                    r2 = await self.client.chat.completions.create(
                        model=self.model_id, messages=messages, max_tokens=256,
                    )
                text = r2.choices[0].message.content
                return (idx, text.strip() if text else f"{self.entity_name} 1", False)
            except Exception as e:
                if attempt < max_retries - 1:
                    is_rate = "429" in str(e) or "rate" in str(e).lower()
                    base_wait = (10 + 5 * attempt) if is_rate else 2 ** (attempt + 1)
                    await asyncio.sleep(base_wait * (0.5 + random.random()))
                else:
                    return (idx, f"{self.entity_name} 1", True)
        return (idx, f"{self.entity_name} 1", True)

    async def _generate_self_consistency(self, prompt: str, idx: int, n_paths: int = 5) -> Tuple[int, str, bool]:
        """自洽采样：n_paths 路并发推理 + 多数投票"""
        tasks = [
            self._generate_with_params(prompt, idx, max_tokens=512, temperature=0.7)
            for _ in range(n_paths)
        ]
        results = await asyncio.gather(*tasks)
        # 提取每条的选择，多数投票
        choices = [extract_choice(r[1], entity=self.entity_name, n_options=self.n_options) for r in results]
        valid = [c for c in choices if c != -1]
        if valid:
            from collections import Counter
            winner = Counter(valid).most_common(1)[0][0]
        else:
            winner = 0
        return (idx, f"{self.entity_name} {winner + 1}", False)

    # ==========================================
    # 消息格式消融策略（实验 5：信任梯度）
    # ==========================================
    async def _generate_system_inject(self, prompt: str, bayes_info: dict, idx: int) -> Tuple[int, str, bool]:
        """system_inject: 将贝叶斯分析放在 role:system 消息中"""
        max_retries = 3
        for attempt in range(max_retries):
            try:
                math_report = self.injector.format_math_report(bayes_info)
                messages = [
                    {"role": "system", "content": (
                        f"You are a helpful {self.entity_name.lower()} recommendation assistant. "
                        "You have access to the following Bayesian analysis of the user's preferences:\n\n"
                        f"{math_report}\n\n"
                        "Use this analysis to inform your recommendation."
                    )},
                    {"role": "user", "content": prompt},
                ]
                async with self.semaphore:
                    api_params = {
                        "model": self.model_id,
                        "messages": messages,
                        "max_tokens": 128,
                    }
                    if not self._should_skip_temp():
                        api_params["temperature"] = self.temperature
                    response = await self.client.chat.completions.create(**api_params)
                text = response.choices[0].message.content
                return (idx, text.strip() if text else f"{self.entity_name} 1", False)
            except Exception as e:
                if attempt < max_retries - 1:
                    is_rate = "429" in str(e) or "rate" in str(e).lower()
                    base_wait = (10 + 5 * attempt) if is_rate else 2 ** (attempt + 1)
                    await asyncio.sleep(base_wait * (0.5 + random.random()))
                else:
                    return (idx, f"{self.entity_name} 1", True)
        return (idx, f"{self.entity_name} 1", True)

    async def _generate_user_separate(self, prompt: str, bayes_info: dict, idx: int) -> Tuple[int, str, bool]:
        """user_separate: 贝叶斯分析作为独立的 role:user 消息（在末尾，避免 lost-in-the-middle）"""
        max_retries = 3
        for attempt in range(max_retries):
            try:
                math_report = self.injector.format_math_report(bayes_info)
                messages = [
                    {"role": "user", "content": prompt},
                    {"role": "assistant", "content": f"Let me analyze the {self.entity_name.lower()} options for this user."},
                    {"role": "user", "content": (
                        f"Before you decide, here is a Bayesian analysis of the user's preferences:\n\n"
                        f"{math_report}\n\n"
                        f'Please consider this analysis and state your final answer as "{self.entity_name} X".'
                    )},
                ]
                async with self.semaphore:
                    api_params = {
                        "model": self.model_id,
                        "messages": messages,
                        "max_tokens": 128,
                    }
                    if not self._should_skip_temp():
                        api_params["temperature"] = self.temperature
                    response = await self.client.chat.completions.create(**api_params)
                text = response.choices[0].message.content
                return (idx, text.strip() if text else f"{self.entity_name} 1", False)
            except Exception as e:
                if attempt < max_retries - 1:
                    is_rate = "429" in str(e) or "rate" in str(e).lower()
                    base_wait = (10 + 5 * attempt) if is_rate else 2 ** (attempt + 1)
                    await asyncio.sleep(base_wait * (0.5 + random.random()))
                else:
                    return (idx, f"{self.entity_name} 1", True)
        return (idx, f"{self.entity_name} 1", True)

    async def _generate_user_separate_rec(self, prompt: str, bayes_info: dict, idx: int) -> Tuple[int, str, bool]:
        """user_separate_rec: 仅推荐（非完整分析）作为独立 role:user 末尾消息"""
        max_retries = 3
        for attempt in range(max_retries):
            try:
                rec = bayes_info.get("recommendation", 0) + 1
                messages = [
                    {"role": "user", "content": prompt},
                    {"role": "assistant", "content": f"Let me analyze the {self.entity_name.lower()} options for this user."},
                    {"role": "user", "content": (
                        f"Before you decide: A mathematical Bayesian analysis suggests {self.entity_name} {rec} "
                        f"is the best option for this user. "
                        f'Please consider this and state your final answer as "{self.entity_name} X".'
                    )},
                ]
                async with self.semaphore:
                    api_params = {
                        "model": self.model_id,
                        "messages": messages,
                        "max_tokens": 128,
                    }
                    if not self._should_skip_temp():
                        api_params["temperature"] = self.temperature
                    response = await self.client.chat.completions.create(**api_params)
                text = response.choices[0].message.content
                return (idx, text.strip() if text else f"{self.entity_name} 1", False)
            except Exception as e:
                if attempt < max_retries - 1:
                    is_rate = "429" in str(e) or "rate" in str(e).lower()
                    base_wait = (10 + 5 * attempt) if is_rate else 2 ** (attempt + 1)
                    await asyncio.sleep(base_wait * (0.5 + random.random()))
                else:
                    return (idx, f"{self.entity_name} 1", True)
        return (idx, f"{self.entity_name} 1", True)

    async def _generate_assistant_inject(self, prompt: str, bayes_info: dict, idx: int) -> Tuple[int, str, bool]:
        """assistant_inject: 贝叶斯分析放在 role:assistant 消息中（模拟模型"已经分析过"）"""
        max_retries = 3
        for attempt in range(max_retries):
            try:
                math_report = self.injector.format_math_report(bayes_info)
                rec = bayes_info.get("recommendation", 0) + 1
                messages = [
                    {"role": "user", "content": prompt},
                    {"role": "assistant", "content": (
                        f"Let me analyze the user's preference patterns using Bayesian inference.\n\n"
                        f"{math_report}\n\n"
                        f"Based on this analysis, {self.entity_name} {rec} appears to be the best match."
                    )},
                    {"role": "user", "content": (
                        f"Now please make your final choice. Which {self.entity_name.lower()} is the best option? "
                        f'State your answer as "{self.entity_name} X".'
                    )},
                ]
                async with self.semaphore:
                    api_params = {
                        "model": self.model_id,
                        "messages": messages,
                        "max_tokens": 128,
                    }
                    if not self._should_skip_temp():
                        api_params["temperature"] = self.temperature
                    response = await self.client.chat.completions.create(**api_params)
                text = response.choices[0].message.content
                return (idx, text.strip() if text else f"{self.entity_name} 1", False)
            except Exception as e:
                if attempt < max_retries - 1:
                    is_rate = "429" in str(e) or "rate" in str(e).lower()
                    base_wait = (10 + 5 * attempt) if is_rate else 2 ** (attempt + 1)
                    await asyncio.sleep(base_wait * (0.5 + random.random()))
                else:
                    return (idx, f"{self.entity_name} 1", True)
        return (idx, f"{self.entity_name} 1", True)

    async def _generate_fake_tool(self, prompt: str, bayes_info: dict, idx: int) -> Tuple[int, str, bool]:
        """fake_tool: 伪造完整的 tool call 历史（role:assistant + tool_calls + role:tool）"""
        max_retries = 3
        for attempt in range(max_retries):
            try:
                tool_result = self.injector.format_tool_response("tool_use", bayes_info)
                # 使用确定性但格式逼真的 tool_call_id
                import hashlib
                call_id = "call_" + hashlib.md5(f"bayes_{idx}_{attempt}".encode()).hexdigest()[:24]
                messages = [
                    {"role": "user", "content": prompt},
                    {
                        "role": "assistant",
                        "content": None,
                        "tool_calls": [{
                            "id": call_id,
                            "type": "function",
                            "function": {
                                "name": "bayesian_analyze",
                                "arguments": json.dumps({"reason": "Analyze user preference weights based on their past choices"})
                            }
                        }]
                    },
                    {
                        "role": "tool",
                        "tool_call_id": call_id,
                        "content": tool_result,
                    },
                ]
                async with self.semaphore:
                    api_params = {
                        "model": self.model_id,
                        "messages": messages,
                        "max_tokens": 128,
                    }
                    if not self._should_skip_temp():
                        api_params["temperature"] = self.temperature
                    response = await self.client.chat.completions.create(**api_params)
                text = response.choices[0].message.content
                return (idx, text.strip() if text else f"{self.entity_name} 1", False)
            except Exception as e:
                if attempt < max_retries - 1:
                    is_rate = "429" in str(e) or "rate" in str(e).lower()
                    base_wait = (10 + 5 * attempt) if is_rate else 2 ** (attempt + 1)
                    await asyncio.sleep(base_wait * (0.5 + random.random()))
                else:
                    return (idx, f"{self.entity_name} 1", True)
        return (idx, f"{self.entity_name} 1", True)

    # 消息格式消融策略集合
    FORMAT_ABLATION_STRATEGIES = {"system_inject", "user_separate", "assistant_inject", "fake_tool"}

    # 所有使用 function calling 的策略
    TOOL_STRATEGIES = {"tool_use", "tool_direct_rec", "tool_nl_pref",
                       "tool_nl_pref_rec", "tool_random_rec", "tool_empty"}

    async def run(self, eval_data: List[Dict], progress_callback=None, progress_dir=None) -> Dict:
        """运行完整实验（异步版本，支持轮次级断点续传）"""
        num_rounds = 5
        num_samples = len(eval_data)
        start_time = time.time()

        # 进度文件路径（round_only 模式也支持断点续传）
        progress_file = None
        if progress_dir:
            progress_file = os.path.join(progress_dir, f"{self.run_label}_progress.json")

        # round_only 模式：仅跑指定轮次，前序轮次用真标签预计算贝叶斯状态
        if self.round_only is not None:
            target_round = self.round_only  # 0-indexed
            sidecars = [BayesianSidecar(preference_values=self.preference_values) for _ in range(num_samples)]
            all_histories = [[] for _ in range(num_samples)]
            # 预计算前序轮次的贝叶斯状态 + 补建对话历史（纯 CPU，不调 API）
            # 注意：history 中的 prediction 使用贝叶斯推荐（非 LLM 预测），因此
            # round_only 模式的 R5 prompt 与完整 5 轮运行的 R5 prompt 不完全等价
            # （历史反馈中的"模型预测"来自贝叶斯算法而非 LLM），是一种合理近似
            for ri in range(target_round):
                for si, sample in enumerate(eval_data):
                    rd = sample["rounds"][ri]
                    user_choice = rd["user_idx"]
                    options_numpy = sample["rounds_numpy"][ri]
                    # 用当前后验的贝叶斯推荐作为模拟预测（在 update 之前调用）
                    fake_pred = sidecars[si].recommend(options_numpy)
                    sidecars[si].update(user_choice, options_numpy)
                    # 补建对话历史，使 R5 prompt 包含完整的 R1-R4 交互上下文
                    all_histories[si].append({
                        "options": rd["options"],
                        "user_choice": user_choice,
                        "prediction": fake_pred,
                        "correct": fake_pred == user_choice,
                    })
            # 直接跳到目标轮次
            round_accuracies = {}
            detailed_records = []
            api_failures = 0
            start_round = target_round
            print(
                f"  [{self.run_label[:50]}] round-only 模式: 仅跑 R{target_round+1} "
                f"(已预计算 {target_round} 轮贝叶斯状态)",
                flush=True,
            )
        else:
            # 正常模式
            # 尝试恢复进度
            start_round, round_accuracies, detailed_records, all_histories = self._try_resume(
                progress_file, eval_data, num_samples
            )
            api_failures = sum(1 for r in detailed_records if r.get("api_fallback"))

            # 重建 BayesianSidecar 后验（从已有记录 replay）
            sidecars = self._rebuild_sidecars(eval_data, detailed_records, num_samples)

            if start_round > 0:
                print(
                    f"  [{self.run_label[:50]}] 从 R{start_round+1} 恢复 "
                    f"(已完成 {start_round} 轮)",
                    flush=True,
                )

        # few_shot 范例文本（所有样本共享，只加载一次）
        if self.strategy == "few_shot":
            self._few_shot_text = build_few_shot_examples()

        for round_idx in range(start_round, num_rounds):
            # round_only 模式下只跑目标轮次
            if self.round_only is not None and round_idx != self.round_only:
                continue
            prompts = []
            user_choices = []
            bayes_recs = []
            bayes_infos = []

            # 准备本轮所有样本的 prompt（CPU 计算，同步即可）
            for si, sample in enumerate(eval_data):
                rd = sample["rounds"][round_idx]
                options_text = rd["options"]
                options_numpy = sample["rounds_numpy"][round_idx]
                user_choice = rd["user_idx"]
                features = sample.get("features", [])

                # 贝叶斯旁路计算
                ba = sidecars[si]
                bayes_rec = ba.recommend(options_numpy)
                bayes_recs.append(bayes_rec)

                # 构造贝叶斯信息
                bayes_info = {
                    "recommendation": bayes_rec,
                    "nl_preference": ba.get_nl_preference(features),
                    "top_beliefs": ba.get_top_beliefs(3),
                    "expected_utilities": ba.get_expected_utilities(options_numpy),
                    "confidence": ba.get_confidence(),
                    "entity_name": self.entity_name,
                    "features": features,
                }

                # random_rec / tool_random_rec 策略：用随机推荐替换贝叶斯推荐
                if self.strategy in ("random_rec", "tool_random_rec"):
                    bayes_info["recommendation"] = random.randint(0, len(options_numpy) - 1)

                # few_shot 策略：传入预编译的范例文本
                if self.strategy == "few_shot":
                    bayes_info["few_shot_examples"] = self._few_shot_text

                # 构造原始 prompt + 注入
                original_prompt = format_round_prompt(options_text, all_histories[si])
                enhanced_prompt = self.injector.inject(
                    self.strategy, original_prompt, bayes_info
                )

                prompts.append(enhanced_prompt)
                user_choices.append(user_choice)
                bayes_infos.append(bayes_info)

            # 批量并发调用 LLM（根据策略选择不同生成方法）
            cot_single_strategies = {"cot_reflect", "cot_bayesian", "few_shot", "math_then_cot"}
            if self.strategy in self.TOOL_STRATEGIES:
                tasks = [
                    self._generate_tool_use(p, bayes_infos[i], i)
                    for i, p in enumerate(prompts)
                ]
            elif self.strategy == "system_inject":
                tasks = [
                    self._generate_system_inject(p, bayes_infos[i], i)
                    for i, p in enumerate(prompts)
                ]
            elif self.strategy == "user_separate":
                tasks = [
                    self._generate_user_separate(p, bayes_infos[i], i)
                    for i, p in enumerate(prompts)
                ]
            elif self.strategy == "user_separate_rec":
                tasks = [
                    self._generate_user_separate_rec(p, bayes_infos[i], i)
                    for i, p in enumerate(prompts)
                ]
            elif self.strategy == "assistant_inject":
                tasks = [
                    self._generate_assistant_inject(p, bayes_infos[i], i)
                    for i, p in enumerate(prompts)
                ]
            elif self.strategy == "fake_tool":
                tasks = [
                    self._generate_fake_tool(p, bayes_infos[i], i)
                    for i, p in enumerate(prompts)
                ]
            elif self.strategy == "cot_then_math":
                tasks = [
                    self._generate_cot_then_math(p, bayes_infos[i], i)
                    for i, p in enumerate(prompts)
                ]
            elif self.strategy == "cot_self_consistency":
                tasks = [
                    self._generate_self_consistency(p, i)
                    for i, p in enumerate(prompts)
                ]
            elif self.strategy in cot_single_strategies:
                tasks = [
                    self._generate_with_params(p, i, max_tokens=512)
                    for i, p in enumerate(prompts)
                ]
            else:
                tasks = [
                    self._generate_single(p, i)
                    for i, p in enumerate(prompts)
                ]
            # round_only 模式：逐批处理并保存中间结果，支持样本级断点续传
            if self.round_only is not None and progress_file:
                # 检查是否有已完成的样本（从进度文件恢复）
                completed_samples = set()
                partial_records = []
                if os.path.exists(progress_file):
                    try:
                        with open(progress_file, "r", encoding="utf-8") as pf:
                            partial_progress = json.load(pf)
                        partial_records = partial_progress.get("detailed_records", [])
                        completed_samples = {r["sample_idx"] for r in partial_records}
                        if completed_samples:
                            # 恢复已有记录到 detailed_records
                            detailed_records.extend(partial_records)
                            print(
                                f"  [{self.run_label[:50]}] 恢复 {len(completed_samples)}/{num_samples} 个已完成样本",
                                flush=True,
                            )
                    except Exception:
                        pass

                # 过滤掉已完成的 tasks
                pending_tasks = []
                pending_indices = []
                for i, task in enumerate(tasks):
                    if i not in completed_samples:
                        pending_tasks.append(task)
                        pending_indices.append(i)

                if not pending_tasks:
                    # 全部已完成
                    api_results = []
                else:
                    # 分批执行，每 100 个样本保存一次
                    batch_size = 100
                    api_results = []
                    for batch_start in range(0, len(pending_tasks), batch_size):
                        batch_end = min(batch_start + batch_size, len(pending_tasks))
                        batch = pending_tasks[batch_start:batch_end]
                        batch_results = await asyncio.gather(*batch)
                        api_results.extend(batch_results)

                        # 保存中间进度
                        batch_records = list(detailed_records)  # 包含恢复的记录
                        for rt in api_results:
                            idx_r = rt[0]
                            # 临时记录用于保存进度
                            text_r = rt[1]
                            fb_r = rt[2]
                            uc = user_choices[idx_r]
                            br = bayes_recs[idx_r]
                            pred_raw = extract_choice(text_r, entity=self.entity_name, n_options=self.n_options)
                            pred = 0 if pred_raw == -1 else pred_raw
                            batch_records.append({
                                "sample_idx": idx_r,
                                "round": round_idx,
                                "ground_truth": uc,
                                "bayes_rec": br,
                                "bayes_correct": br == uc,
                                "llm_choice": pred,
                                "llm_correct": pred == uc,
                                "followed_bayes": pred == br,
                                "api_fallback": fb_r,
                                "parse_failed": pred_raw == -1,
                            })

                        # 去重后保存
                        seen = set()
                        unique_records = []
                        for r in batch_records:
                            key = (r["sample_idx"], r["round"])
                            if key not in seen:
                                seen.add(key)
                                unique_records.append(r)

                        with open(progress_file, "w", encoding="utf-8") as pf:
                            json.dump({
                                "last_completed_round": round_idx - 1,
                                "round_accuracies": {},
                                "detailed_records": unique_records,
                                "all_histories": all_histories,
                            }, pf, ensure_ascii=False)

                        done_count = len(completed_samples) + len(api_results)
                        print(
                            f"  [{self.run_label[:50]}] 进度: {done_count}/{num_samples} "
                            f"({done_count/num_samples*100:.0f}%)",
                            flush=True,
                        )
                    # 清除恢复的记录，后面会重新统计
                    detailed_records = [r for r in detailed_records if r.get("round") != round_idx]
            else:
                api_results = await asyncio.gather(*tasks)

            # 整理结果（tool_use 返回 4 元组，其他 3 元组）
            results_list = [None] * num_samples
            fallback_flags = [False] * num_samples
            tool_call_flags = [False] * num_samples

            # 先填入恢复的结果（round_only 断点续传）
            if self.round_only is not None and progress_file:
                for r in (partial_records if 'partial_records' in dir() else []):
                    si = r["sample_idx"]
                    results_list[si] = f"{self.entity_name} {r['llm_choice'] + 1}"
                    fallback_flags[si] = r.get("api_fallback", False)

            for result_tuple in api_results:
                idx, text, is_fallback = result_tuple[0], result_tuple[1], result_tuple[2]
                results_list[idx] = text
                fallback_flags[idx] = is_fallback
                if is_fallback:
                    api_failures += 1
                if len(result_tuple) > 3:
                    tool_call_flags[idx] = result_tuple[3]

            # 通知进度
            if progress_callback:
                progress_callback(num_samples)

            # 统计本轮
            correct_count = 0
            for si in range(num_samples):
                response = results_list[si]
                user_choice = user_choices[si]
                bayes_rec = bayes_recs[si]

                prediction_raw = extract_choice(response, entity=self.entity_name, n_options=self.n_options)
                parse_failed = (prediction_raw == -1)
                prediction = 0 if parse_failed else prediction_raw

                is_correct = prediction == user_choice
                bayes_correct = bayes_rec == user_choice
                followed_bayes = prediction == bayes_rec

                if is_correct:
                    correct_count += 1

                record = {
                    "sample_idx": si,
                    "round": round_idx,
                    "ground_truth": user_choice,
                    "bayes_rec": bayes_rec,
                    "bayes_correct": bayes_correct,
                    "llm_choice": prediction,
                    "llm_correct": is_correct,
                    "followed_bayes": followed_bayes,
                    "api_fallback": fallback_flags[si],
                    "parse_failed": parse_failed,
                }
                if self.strategy in self.TOOL_STRATEGIES:
                    record["tool_called"] = tool_call_flags[si]
                detailed_records.append(record)

                # 更新对话历史
                rd = eval_data[si]["rounds"][round_idx]
                all_histories[si].append({
                    "options": rd["options"],
                    "user_choice": user_choice,
                    "prediction": prediction,
                    "correct": is_correct,
                })

                # 贝叶斯助手用真实用户选择更新信念
                options_numpy = eval_data[si]["rounds_numpy"][round_idx]
                sidecars[si].update(user_choice, options_numpy)

            accuracy = correct_count / num_samples
            round_accuracies[round_idx] = accuracy
            avg_acc = sum(round_accuracies.values()) / len(round_accuracies)
            print(
                f"  [{self.run_label[:50]}] R{round_idx+1}: "
                f"{accuracy*100:.1f}%  Avg: {avg_acc*100:.1f}%",
                flush=True,
            )

            # 每轮完成后保存进度（轮次级断点续传）
            if progress_file:
                self._save_progress(
                    progress_file, round_idx, round_accuracies,
                    detailed_records, all_histories,
                )

        # 全部完成，删除进度文件
        if progress_file and os.path.exists(progress_file):
            os.remove(progress_file)

        elapsed = time.time() - start_time
        overall_accuracy = sum(round_accuracies.values()) / len(round_accuracies)

        # 解析失败统计（round-only 模式只跑 1 轮，分母用实际轮数）
        parse_failures = sum(1 for r in detailed_records if r.get("parse_failed"))
        actual_rounds = len(round_accuracies)
        total_requests = num_samples * actual_rounds

        # 信任校准指标
        trust_metrics = self._compute_trust_metrics(detailed_records)

        result = {
            "model_id": self.model_id,
            "strategy": self.strategy,
            "run_label": self.run_label,
            "round_accuracies": {str(k): v for k, v in round_accuracies.items()},
            "overall_accuracy": overall_accuracy,
            "total_samples": num_samples,
            "api_failures": api_failures,
            "api_failure_rate": api_failures / total_requests if total_requests > 0 else 0,
            "parse_failures": parse_failures,
            "parse_failure_rate": parse_failures / total_requests if total_requests > 0 else 0,
            "total_time": elapsed,
            "trust_metrics": trust_metrics,
            "detailed_records": detailed_records,
            "completed_at": datetime.now().isoformat(),
        }

        fail_info = f"  API失败: {api_failures}" if api_failures > 0 else ""
        parse_info = f"  解析失败: {parse_failures}" if parse_failures > 0 else ""
        print(
            f"  >>> [{self.run_label[:50]}] 完成! "
            f"准确率: {overall_accuracy*100:.2f}%  "
            f"Follow: {trust_metrics['follow_rate']*100:.1f}%  "
            f"BayesAcc: {trust_metrics['bayes_accuracy']*100:.1f}%  "
            f"耗时: {elapsed:.1f}s{fail_info}{parse_info}",
            flush=True,
        )

        return result

    def _try_resume(self, progress_file, eval_data, num_samples):
        """尝试从进度文件恢复，返回 (start_round, round_accuracies, detailed_records, all_histories)"""
        if progress_file and os.path.exists(progress_file):
            try:
                with open(progress_file, "r", encoding="utf-8") as f:
                    progress = json.load(f)
                start_round = progress["last_completed_round"] + 1
                round_accuracies = {int(k): v for k, v in progress["round_accuracies"].items()}
                detailed_records = progress["detailed_records"]
                all_histories = progress["all_histories"]
                return start_round, round_accuracies, detailed_records, all_histories
            except Exception as e:
                print(f"  [{self.run_label[:50]}] 进度文件损坏，从头开始: {e}", flush=True)
        return 0, {}, [], [[] for _ in range(num_samples)]

    def _save_progress(self, progress_file, round_idx, round_accuracies, detailed_records, all_histories):
        """保存轮次级进度（安全写入：先写临时文件再 rename）"""
        progress = {
            "last_completed_round": round_idx,
            "round_accuracies": {str(k): v for k, v in round_accuracies.items()},
            "detailed_records": detailed_records,
            "all_histories": all_histories,
        }
        progress_dir = os.path.dirname(progress_file)
        fd, tmp_path = tempfile.mkstemp(dir=progress_dir, suffix=".tmp")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(progress, f, ensure_ascii=False, separators=(',', ':'))
            os.replace(tmp_path, progress_file)
        except Exception:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
            raise

    def _rebuild_sidecars(self, eval_data, detailed_records, num_samples):
        """从已有记录重建 BayesianSidecar 后验"""
        sidecars = []
        for sample in eval_data:
            feat_dim = len(sample.get("features", ["a", "b", "c", "d"]))
            sidecars.append(BayesianSidecar(feature_dim=feat_dim, preference_values=self.preference_values))
        # replay 已有记录的 update 调用
        for record in detailed_records:
            si = record["sample_idx"]
            ri = record["round"]
            user_choice = record["ground_truth"]
            options_numpy = eval_data[si]["rounds_numpy"][ri]
            sidecars[si].update(user_choice, options_numpy)
        return sidecars

    def _compute_trust_metrics(self, records: List[Dict]) -> Dict:
        """计算信任校准指标"""
        total = len(records)
        if total == 0:
            return {"follow_rate": 0, "follow_when_correct": 0, "follow_when_wrong": 0,
                    "calibration_score": 0, "bayes_accuracy": 0, "bayes_per_round": {}}

        followed = sum(1 for r in records if r["followed_bayes"])
        bc = [r for r in records if r["bayes_correct"]]
        bw = [r for r in records if not r["bayes_correct"]]

        follow_rate = followed / total
        fwc = sum(1 for r in bc if r["followed_bayes"]) / len(bc) if bc else 0.0
        fww = sum(1 for r in bw if r["followed_bayes"]) / len(bw) if bw else 0.0
        bayes_accuracy = len(bc) / total

        # 按轮次的贝叶斯准确率
        bayes_per_round = {}
        for ri in range(5):
            rr = [r for r in records if r["round"] == ri]
            if rr:
                bayes_per_round[str(ri)] = sum(1 for r in rr if r["bayes_correct"]) / len(rr)

        # Bootstrap 置信区间
        overall_flags = [int(r["llm_correct"]) for r in records]
        overall_ci = compute_bootstrap_ci(overall_flags)

        per_round_ci = {}
        for ri in range(5):
            round_flags = [int(r["llm_correct"]) for r in records if r["round"] == ri]
            if round_flags:
                per_round_ci[str(ri)] = compute_bootstrap_ci(round_flags)

        # 工具调用率（仅 tool_* 策略有此字段）
        tool_records = [r for r in records if "tool_called" in r]
        if tool_records:
            tool_call_rate = sum(1 for r in tool_records if r["tool_called"]) / len(tool_records)
            tool_call_per_round = {}
            for ri in range(5):
                rr = [r for r in tool_records if r["round"] == ri]
                if rr:
                    tool_call_per_round[str(ri)] = sum(1 for r in rr if r["tool_called"]) / len(rr)
        else:
            tool_call_rate = None
            tool_call_per_round = None

        return {
            "follow_rate": follow_rate,
            "follow_when_correct": fwc,
            "follow_when_wrong": fww,
            "calibration_score": fwc - fww,
            "bayes_accuracy": bayes_accuracy,
            "bayes_per_round": bayes_per_round,
            "overall_ci": overall_ci,
            "per_round_ci": per_round_ci,
            "tool_call_rate": tool_call_rate,
            "tool_call_per_round": tool_call_per_round,
        }


# ==========================================
# 汇总报告
# ==========================================
def generate_sidecar_summary(results: Dict, output_dir: str, n_samples: int):
    """生成旁路注入实验汇总报告"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

    # JSON 汇总（不含 detailed_records，避免文件过大）
    summary = {}
    for label, r in results.items():
        if r is None:
            continue
        summary[label] = {
            "model_id": r["model_id"],
            "strategy": r["strategy"],
            "overall_accuracy": r["overall_accuracy"],
            "round_accuracies": r["round_accuracies"],
            "trust_metrics": r.get("trust_metrics", {}),
            "total_time": r["total_time"],
        }

    summary_file = os.path.join(output_dir, f"summary_{timestamp}.json")
    with open(summary_file, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    latest = os.path.join(output_dir, "summary.json")
    with open(latest, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2, ensure_ascii=False)

    # Markdown 报告
    md_file = os.path.join(output_dir, f"report_{timestamp}.md")
    with open(md_file, "w", encoding="utf-8") as f:
        f.write("# 贝叶斯旁路注入实验报告\n\n")
        f.write(f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"**样本数**: {n_samples}\n\n")

        # 按模型分组
        by_model = defaultdict(list)
        for label, r in summary.items():
            by_model[r["model_id"]].append(r)

        for mid, runs in sorted(by_model.items()):
            f.write(f"## {mid}\n\n")
            f.write("| 策略 | 总体准确率 | 95% CI | R1 | R2 | R3 | R4 | R5 | R5 CI | Follow% | Calibration | BayesAcc |\n")
            f.write("|------|-----------|--------|----|----|----|----|----|----|---------|-------------|----------|\n")
            for r in sorted(runs, key=lambda x: x["overall_accuracy"], reverse=True):
                ra = r["round_accuracies"]
                tm = r.get("trust_metrics", {})
                oci = tm.get("overall_ci", {})
                r5ci = tm.get("per_round_ci", {}).get("4", {})
                ci_str = f"[{oci.get('ci_lower',0)*100:.1f}, {oci.get('ci_upper',0)*100:.1f}]" if oci else "-"
                r5ci_str = f"[{r5ci.get('ci_lower',0)*100:.1f}, {r5ci.get('ci_upper',0)*100:.1f}]" if r5ci else "-"
                f.write(
                    f"| {r['strategy']} "
                    f"| **{r['overall_accuracy']*100:.2f}%** "
                    f"| {ci_str} "
                    f"| {ra.get('0',0)*100:.1f}% "
                    f"| {ra.get('1',0)*100:.1f}% "
                    f"| {ra.get('2',0)*100:.1f}% "
                    f"| {ra.get('3',0)*100:.1f}% "
                    f"| {ra.get('4',0)*100:.1f}% "
                    f"| {r5ci_str} "
                    f"| {tm.get('follow_rate',0)*100:.1f}% "
                    f"| {tm.get('calibration_score',0)*100:.1f}% "
                    f"| {tm.get('bayes_accuracy',0)*100:.1f}% "
                    f"|\n"
                )
            f.write("\n")

        # 贝叶斯助手自身逐轮准确率
        f.write("## 贝叶斯助手自身表现\n\n")
        f.write("(取任一非 baseline 实验的 bayes_per_round)\n\n")
        for label, r in summary.items():
            tm = r.get("trust_metrics", {})
            bpr = tm.get("bayes_per_round", {})
            if bpr:
                f.write(f"| Round | Bayes Accuracy |\n|-------|---------------|\n")
                for ri in range(5):
                    acc = bpr.get(str(ri), 0)
                    f.write(f"| R{ri+1} | {acc*100:.1f}% |\n")
                f.write("\n")
                break

    print(f"\n[汇总] JSON: {summary_file}")
    print(f"[汇总] Markdown: {md_file}")

    # 控制台汇总
    print("\n" + "=" * 110)
    print("旁路注入实验汇总")
    print("=" * 110)
    print(f"{'模型':<35} {'策略':<15} {'准确率':>8} {'R5':>6} {'Follow':>8} {'FwC':>8} {'FwW':>8} {'Calib':>8} {'BayesAcc':>8}")
    print("-" * 110)
    sorted_results = sorted(summary.values(), key=lambda x: (x["model_id"], -x["overall_accuracy"]))
    for r in sorted_results:
        tm = r.get("trust_metrics", {})
        ra = r.get("round_accuracies", {})
        print(
            f"{r['model_id']:<35} {r['strategy']:<15} "
            f"{r['overall_accuracy']*100:>7.2f}% "
            f"{ra.get('4',0)*100:>5.1f}% "
            f"{tm.get('follow_rate',0)*100:>7.1f}% "
            f"{tm.get('follow_when_correct',0)*100:>7.1f}% "
            f"{tm.get('follow_when_wrong',0)*100:>7.1f}% "
            f"{tm.get('calibration_score',0)*100:>7.1f}% "
            f"{tm.get('bayes_accuracy',0)*100:>7.1f}%"
        )
    print("=" * 110)


# ==========================================
# 命令行和主函数
# ==========================================
def parse_args():
    parser = argparse.ArgumentParser(
        description="贝叶斯旁路注入实验（asyncio 版本）",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python run_sidecar_experiment.py -n 50 -m openai/gpt-4o-mini --strategies direct_rec
  python run_sidecar_experiment.py -m openai/gpt-4o openai/gpt-4o-mini --strategies all
  python run_sidecar_experiment.py --list-strategies
        """
    )
    parser.add_argument("-m", "--models", nargs="+", help="模型 ID 列表")
    parser.add_argument(
        "--strategies", nargs="+", default=["all"],
        help="注入策略 (baseline/direct_rec/nl_preference/nl_pref_rec/full_math/random_rec/all)",
    )
    parser.add_argument("-n", "--max-samples", type=int, default=None, help="最大样本数")
    parser.add_argument("--dataset", type=str, default="flight",
                        help="数据集名称 (flight/hotel/flight_2features/flight_3features)，对应 data/eval/interaction/ 下的 JSONL 文件")
    parser.add_argument("--split", type=str, default=None, choices=["dev", "test"],
                        help="使用 dev/test 分离 (dev=前20%%, test=后80%%)，固定 seed 随机分层切分")
    parser.add_argument("--per-model", type=int, default=200, help="每个模型的最大并发 API 请求数")
    parser.add_argument("--no-resume", action="store_true", help="不使用断点续传")
    parser.add_argument("--round-only", type=int, default=None, choices=[1,2,3,4,5],
                        help="仅跑指定轮次（如 --round-only 5 只跑 R5），前序轮次用真标签预计算贝叶斯状态")
    parser.add_argument("--list-strategies", action="store_true", help="列出所有策略")
    return parser.parse_args()


async def async_main():
    args = parse_args()

    if args.list_strategies:
        print("可用注入策略:\n")
        descriptions = {
            "baseline": "无注入（对照组）",
            "direct_rec": "仅推荐 — 'Bayesian analysis suggests Option X'",
            "nl_preference": "自然语言偏好描述 — 'Prefers cheaper options (strong preference)'",
            "nl_pref_rec": "自然语言偏好 + 推荐",
            "full_math": "完整数学分析 — 权重、概率、期望效用",
            "random_rec": "随机推荐控制组 — 格式同 direct_rec，但推荐随机航班",
            # Tool Calling 内容消融
            "tool_direct_rec": "工具返回仅推荐 — 'Option X is the best option'",
            "tool_nl_pref": "工具返回自然语言偏好描述",
            "tool_nl_pref_rec": "工具返回自然语言偏好 + 推荐",
            "tool_random_rec": "工具返回随机推荐（控制组）",
            "tool_empty": "工具返回无信息 — 'Insufficient data'",
            # 消息格式消融（实验 5）
            "system_inject": "贝叶斯分析放在 role:system 消息中",
            "user_separate": "贝叶斯分析作为独立 role:user 消息（末尾位置）",
            "assistant_inject": "贝叶斯分析放在 role:assistant 消息中（模拟已分析过）",
            "fake_tool": "伪造完整 tool call 历史（role:assistant+tool_calls + role:tool）",
        }
        for s, d in descriptions.items():
            print(f"  {s:<20} {d}")
        return

    if not args.models:
        print("[错误] 请指定模型 ID (-m)")
        return

    script_dir = os.path.dirname(os.path.abspath(__file__))
    base_dir = os.path.dirname(script_dir)

    dataset_name = args.dataset
    eval_file = os.path.join(base_dir, "data", "eval", "interaction", f"{dataset_name}.jsonl")
    if not os.path.exists(eval_file):
        print(f"[错误] 数据集文件不存在: {eval_file}")
        return
    results_dir = os.path.join(script_dir, "sidecar_results")
    checkpoint_dir = os.path.join(script_dir, "sidecar_checkpoints")
    os.makedirs(results_dir, exist_ok=True)

    # 加载数据
    print(f"[数据] 加载: {eval_file} (dataset={dataset_name})")
    eval_data = load_eval_data(eval_file, max_samples=args.max_samples)

    # 自动检测实体名称、选项数、preference values（在 split 之前，确保覆盖完整值域）
    first_sample = eval_data[0]
    entity_name = detect_entity_name(first_sample["rounds"][0]["options"])
    n_options = len(first_sample["rounds"][0]["options"])
    print(f"[数据] 实体类型: {entity_name}, 每轮选项数: {n_options}")

    pref_vals_set = set()
    for sample in eval_data:
        for v in sample.get("reward_fn", []):
            pref_vals_set.add(float(v))
    if pref_vals_set:
        preference_values = sorted(pref_vals_set)
        print(f"[数据] 偏好值空间: {preference_values} ({len(preference_values)}^{len(first_sample.get('features',[]))} 假设)")
    else:
        preference_values = None  # 使用 BayesianSidecar 默认值

    # dev/test 分离（固定 seed 随机分层切分）
    if args.split:
        rng = np.random.default_rng(42)
        indices = rng.permutation(len(eval_data))
        split_point = int(len(eval_data) * 0.2)
        if args.split == "dev":
            selected = sorted(indices[:split_point])
        else:
            selected = sorted(indices[split_point:])
        eval_data = [eval_data[i] for i in selected]
        print(f"[数据] {args.split} split: {len(eval_data)} 样本 (共 {len(indices)})")
    else:
        print(f"[数据] 共 {len(eval_data)} 个样本")

    # 确定策略列表
    all_strategies = PromptInjector.STRATEGIES
    if "all" in args.strategies:
        strategies = all_strategies
    else:
        strategies = [s for s in args.strategies if s in all_strategies]
        if not strategies:
            print(f"[错误] 无效策略: {args.strategies}")
            return

    # 构建运行组合
    run_pairs = [(m, s) for m in args.models for s in strategies]

    # 断点续传
    checkpoint_mgr = CheckpointManager(checkpoint_dir)
    if not args.no_resume:
        pending = []
        for model_id, strategy in run_pairs:
            label = f"{model_id.replace('/', '__')}__sidecar_{strategy}"
            if not checkpoint_mgr.is_completed(label):
                pending.append((model_id, strategy))
            else:
                print(f"  [跳过] {label} (已完成)")
        run_pairs = pending

    if not run_pairs:
        print("[信息] 所有实验已完成! 生成汇总...")
        all_results = {}
        for label in checkpoint_mgr.completed:
            r = checkpoint_mgr.get_completed_result(label)
            if r:
                all_results[label] = r
        if all_results:
            generate_sidecar_summary(all_results, results_dir, len(eval_data))
        return

    per_model = args.per_model

    # 按模型分组
    from collections import OrderedDict
    models_strategies = OrderedDict()
    for m, s in run_pairs:
        models_strategies.setdefault(m, []).append(s)

    # 打印配置
    print(f"\n{'='*80}")
    print("贝叶斯旁路注入实验（asyncio 版本）")
    print(f"{'='*80}")
    print(f"  样本数: {len(eval_data)}")
    print(f"  待运行: {len(run_pairs)} 个 (模型×策略)")
    print(f"  每模型并发: {per_model} (模型间完全独立)")
    print()
    for m, strats in models_strategies.items():
        print(f"  {m}: {', '.join(strats)}")
    print(flush=True)

    all_results = {}

    # 加载已完成的结果
    for label in checkpoint_mgr.completed:
        r = checkpoint_mgr.get_completed_result(label)
        if r:
            all_results[label] = r

    # 为每个模型创建独立的 semaphore 和 client
    api_key = os.environ.get("OPENROUTER_API_KEY")
    if not api_key:
        print("[错误] 请设置环境变量 OPENROUTER_API_KEY")
        return

    model_resources = {}
    for model_id in models_strategies:
        sem = asyncio.Semaphore(per_model)
        # httpx 连接池设置得更大，让 semaphore 来控制并发
        http_client = httpx.AsyncClient(
            limits=httpx.Limits(
                max_connections=350,
                max_keepalive_connections=200,
            ),
            timeout=httpx.Timeout(120.0, connect=20.0),
        )
        client = AsyncOpenAI(
            base_url="https://openrouter.ai/api/v1",
            api_key=api_key,
            http_client=http_client,
        )
        model_resources[model_id] = (sem, client)

    # 定义单个运行的异步任务
    async def run_one(model_id: str, strategy: str, delay: float = 0) -> Tuple[str, Optional[Dict]]:
        if delay > 0:
            await asyncio.sleep(delay)
        try:
            sem, client = model_resources[model_id]
            runner = AsyncSidecarRunner(
                model_id=model_id,
                strategy=strategy,
                semaphore=sem,
                client=client,
                round_only=(args.round_only - 1) if args.round_only else None,
                entity_name=entity_name,
                n_options=n_options,
                preference_values=preference_values,
            )
            result = await runner.run(eval_data, progress_dir=checkpoint_dir)
            label = result["run_label"]

            # 分离 detailed_records 到独立 .jsonl 文件，避免汇总 JSON 过大
            detailed = result.pop("detailed_records", [])

            # 异步写入文件，不阻塞事件循环
            def _save_files():
                # 汇总指标（不含 detailed_records，~2KB）
                result_file = os.path.join(results_dir, f"{label}.json")
                with open(result_file, "w", encoding="utf-8") as f:
                    json.dump(result, f, indent=2, ensure_ascii=False)
                # 详细记录（每行一条 JSON，~470KB）
                details_file = os.path.join(results_dir, f"{label}_details.jsonl")
                with open(details_file, "w", encoding="utf-8") as f:
                    for rec in detailed:
                        f.write(json.dumps(rec, ensure_ascii=False, separators=(',', ':')) + "\n")

            await asyncio.to_thread(_save_files)

            # 恢复 detailed_records 供后续汇总使用
            result["detailed_records"] = detailed

            checkpoint_mgr.mark_completed(label, result)
            return label, result
        except Exception as e:
            print(f"  [错误] [{model_id}|{strategy}] {e}", flush=True)
            traceback.print_exc()
            return f"{model_id.replace('/', '__')}__sidecar_{strategy}", None

    # 所有运行并发执行（模型间独立，同模型策略间共享并发池）
    print(f"\n[启动] 并发执行 {len(run_pairs)} 个运行...\n", flush=True)
    start_all = time.time()

    try:
        tasks = [
            run_one(m, s, delay=i * 0.5)
            for i, (m, s) in enumerate(run_pairs)
        ]
        results = await asyncio.gather(*tasks)

        for label, result in results:
            if result is not None:
                all_results[label] = result

        elapsed_all = time.time() - start_all
        print(f"\n[完成] 全部运行耗时: {elapsed_all:.1f}s", flush=True)

        # 生成汇总
        if all_results:
            generate_sidecar_summary(all_results, results_dir, len(eval_data))
    finally:
        # 关闭所有 httpx client，防止 socket 泄漏
        for model_id, (sem, client) in model_resources.items():
            try:
                await client.close()
            except Exception:
                pass


def main():
    asyncio.run(async_main())


if __name__ == "__main__":
    main()

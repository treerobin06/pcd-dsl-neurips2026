#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
贝叶斯网络精确推断模块 — 变量消除

为 BLInD 任务提供精确贝叶斯推断：
1. 从自然语言文本解析 CPT（条件概率表）
2. 从图字符串解析 DAG 结构
3. 通过变量消除计算精确条件/联合概率
"""

import re
import numpy as np
from typing import Dict, List, Tuple, Optional, Set
from itertools import product


class BNSolver:
    """贝叶斯网络精确推断引擎"""

    def __init__(self):
        self.nodes: List[str] = []
        self.parents: Dict[str, List[str]] = {}
        self.cpts: Dict[str, Dict] = {}  # node -> {parent_vals_tuple: {True: p, False: 1-p}}

    def parse_graph(self, graph_str: str):
        """解析 BLInD 格式的图字符串

        格式: "('n1',) -> n0 | ('n0',) -> n1 | () -> n3"
        """
        self.parents = {}
        self.nodes = []
        edges = graph_str.split(" | ")
        for edge in edges:
            edge = edge.strip()
            m = re.match(r'\(([^)]*)\)\s*->\s*(\w+)', edge)
            if not m:
                continue
            parents_str = m.group(1).strip()
            child = m.group(2).strip()

            if parents_str:
                # 解析父节点列表: "'n1', 'n0'" 或 "'n1',"
                parent_list = [p.strip().strip("'\"") for p in parents_str.split(",") if p.strip().strip("'\"")]
            else:
                parent_list = []

            self.parents[child] = parent_list
            if child not in self.nodes:
                self.nodes.append(child)
            for p in parent_list:
                if p not in self.nodes:
                    self.nodes.append(p)

    def parse_cpt(self, context_str: str):
        """解析 BLInD 格式的 CPT 文本

        格式: "If n1 is False, then n0 is True with probability of 39%."
              "If n1 is False, then n0 is False with probability of 61%."
              "The probability that n3 is True is 52%."  (无父节点)
        """
        self.cpts = {}
        sentences = re.split(r'\.\s*', context_str)

        for sent in sentences:
            sent = sent.strip()
            if not sent:
                continue

            # 模式 1: 有条件的 CPT
            # "If X is V1 [and Y is V2], then Z is V3 with probability of P%"
            m = re.match(
                r'If\s+(.+?),\s*then\s+(\w+)\s+is\s+(True|False)\s+with\s+probability\s+of\s+([\d.]+)%',
                sent, re.IGNORECASE
            )
            if m:
                cond_str = m.group(1)
                child = m.group(2)
                child_val = m.group(3).lower() == "true"
                prob = float(m.group(4)) / 100.0

                # 解析条件: "n1 is False and n2 is True"
                conditions = {}
                cond_parts = re.findall(r'(\w+)\s+is\s+(True|False)', cond_str, re.IGNORECASE)
                for var, val in cond_parts:
                    conditions[var] = val.lower() == "true"

                # 存入 CPT
                if child not in self.cpts:
                    self.cpts[child] = {}

                # 用父节点值的元组作为 key（按 self.parents[child] 的顺序）
                parent_order = self.parents.get(child, [])
                parent_vals = tuple(conditions.get(p, True) for p in parent_order)

                if parent_vals not in self.cpts[child]:
                    self.cpts[child][parent_vals] = {}
                self.cpts[child][parent_vals][child_val] = prob
                continue

            # 模式 2: 无条件（先验）
            # "The probability that n3 is True is 52%." 或 "n3 is true with probability of 52%"
            m2 = re.match(
                r'(?:The\s+probability\s+that\s+)?(\w+)\s+is\s+(true|false)\s+(?:is|with\s+probability\s+of)\s+([\d.]+)%',
                sent, re.IGNORECASE
            )
            if m2:
                node = m2.group(1)
                val = m2.group(2).lower() == "true"
                prob = float(m2.group(3)) / 100.0

                if node not in self.cpts:
                    self.cpts[node] = {}
                parent_vals = ()  # 无父节点
                if parent_vals not in self.cpts[node]:
                    self.cpts[node][parent_vals] = {}
                self.cpts[node][parent_vals][val] = prob

    def _get_factor(self, node: str) -> Dict[tuple, float]:
        """获取一个节点的 factor（CPT 展平为联合概率表）

        返回: {(node=T/F, p1=T/F, p2=T/F, ...): probability}
        涉及变量顺序: [node] + parents
        """
        factor = {}
        parent_list = self.parents.get(node, [])
        cpt = self.cpts.get(node, {})

        if not parent_list:
            # 无父节点
            p_true = cpt.get((), {}).get(True, 0.5)
            p_false = cpt.get((), {}).get(False, 1 - p_true)
            factor[(True,)] = p_true
            factor[(False,)] = p_false
        else:
            # 枚举父节点所有取值组合
            for parent_vals in product([True, False], repeat=len(parent_list)):
                probs = cpt.get(parent_vals, {})
                p_true = probs.get(True, 0.5)
                p_false = probs.get(False, 1 - p_true)
                factor[(True,) + parent_vals] = p_true
                factor[(False,) + parent_vals] = p_false

        return factor

    def solve(self, query_str: str) -> Optional[float]:
        """解析查询并用变量消除计算答案

        支持的查询格式:
        - "What is the probability that n0 is True given that n1 is False?"
        - "What is the probability that n0 is True and n1 is False?"
        - "What is the probability that n0 is True and n1 is False given that n2 is True?"

        Returns:
            计算得到的概率值，或 None（解析失败）
        """
        # 解析查询变量和证据
        query_vars, evidence = self._parse_query(query_str)
        if query_vars is None:
            return None

        # 变量消除计算 P(query | evidence)
        return self._variable_elimination(query_vars, evidence)

    def _parse_query(self, query_str: str) -> Tuple[Optional[Dict[str, bool]], Optional[Dict[str, bool]]]:
        """解析查询字符串

        Returns:
            (query_vars, evidence) — 都是 {var_name: bool_value} 字典
        """
        # 分割 given
        parts = re.split(r'\s+given\s+that\s+', query_str, flags=re.IGNORECASE)

        # 解析查询变量
        query_part = parts[0]
        query_vars = {}
        var_matches = re.findall(r'(\w+)\s+is\s+(True|False)', query_part)
        for var, val in var_matches:
            query_vars[var] = val == "True"

        if not query_vars:
            return None, None

        # 解析证据
        evidence = {}
        if len(parts) > 1:
            ev_part = parts[1]
            ev_matches = re.findall(r'(\w+)\s+is\s+(True|False)', ev_part)
            for var, val in ev_matches:
                evidence[var] = val == "True"

        return query_vars, evidence

    def _variable_elimination(
        self, query_vars: Dict[str, bool], evidence: Dict[str, bool]
    ) -> float:
        """变量消除算法

        计算 P(query_vars | evidence)
        """
        # 构建所有 factor
        factors = []
        for node in self.nodes:
            factor_vars = [node] + self.parents.get(node, [])
            raw_factor = self._get_factor(node)
            factors.append((factor_vars, raw_factor))

        # 应用证据：将已知变量固定
        factors = self._apply_evidence(factors, evidence)

        # 需要消除的变量 = 所有变量 - 查询变量 - 证据变量
        all_vars = set()
        for fv, _ in factors:
            all_vars.update(fv)
        eliminate_vars = all_vars - set(query_vars.keys()) - set(evidence.keys())

        # 逐一消除变量
        for var in eliminate_vars:
            factors = self._eliminate_variable(factors, var)

        # 将剩余 factor 相乘
        result = self._multiply_all_factors(factors)

        # 从结果中提取查询值对应的概率
        # result 的变量应该只包含 query_vars 中的变量
        result_vars, result_table = result

        # 归一化（处理证据的边际概率）
        total = sum(result_table.values())
        if total == 0:
            return 0.0

        # 找到匹配 query_vars 的条目
        target_prob = 0.0
        for vals, prob in result_table.items():
            match = True
            for i, var in enumerate(result_vars):
                if var in query_vars and vals[i] != query_vars[var]:
                    match = False
                    break
            if match:
                target_prob += prob

        return target_prob / total

    def _apply_evidence(self, factors, evidence):
        """将证据变量固定到 factor 中"""
        new_factors = []
        for factor_vars, table in factors:
            new_table = {}
            for vals, prob in table.items():
                consistent = True
                for i, var in enumerate(factor_vars):
                    if var in evidence and vals[i] != evidence[var]:
                        consistent = False
                        break
                if consistent:
                    new_table[vals] = prob
            if new_table:
                new_factors.append((factor_vars, new_table))
        return new_factors

    def _eliminate_variable(self, factors, var):
        """消除一个变量：找到包含它的 factor，相乘后求和"""
        # 分离包含/不包含 var 的 factor
        relevant = []
        irrelevant = []
        for fv, table in factors:
            if var in fv:
                relevant.append((fv, table))
            else:
                irrelevant.append((fv, table))

        if not relevant:
            return irrelevant

        # 将 relevant factors 相乘
        product_factor = relevant[0]
        for i in range(1, len(relevant)):
            product_factor = self._multiply_factors(product_factor, relevant[i])

        # 在 var 上求和（边际化）
        prod_vars, prod_table = product_factor
        var_idx = prod_vars.index(var)
        new_vars = [v for i, v in enumerate(prod_vars) if i != var_idx]
        new_table = {}
        for vals, prob in prod_table.items():
            new_vals = tuple(v for i, v in enumerate(vals) if i != var_idx)
            new_table[new_vals] = new_table.get(new_vals, 0) + prob

        irrelevant.append((new_vars, new_table))
        return irrelevant

    def _multiply_factors(self, f1, f2):
        """两个 factor 相乘"""
        vars1, table1 = f1
        vars2, table2 = f2

        # 合并变量
        all_vars = list(vars1)
        for v in vars2:
            if v not in all_vars:
                all_vars.append(v)

        new_table = {}
        for vals1, prob1 in table1.items():
            for vals2, prob2 in table2.items():
                # 检查共享变量一致性
                consistent = True
                combined = {}
                for i, v in enumerate(vars1):
                    combined[v] = vals1[i]
                for i, v in enumerate(vars2):
                    if v in combined:
                        if combined[v] != vals2[i]:
                            consistent = False
                            break
                    else:
                        combined[v] = vals2[i]

                if consistent:
                    new_vals = tuple(combined[v] for v in all_vars)
                    new_table[new_vals] = new_table.get(new_vals, 0) + prob1 * prob2

        return (all_vars, new_table)

    def _multiply_all_factors(self, factors):
        """所有 factor 相乘"""
        if not factors:
            return ([], {(): 1.0})
        result = factors[0]
        for i in range(1, len(factors)):
            result = self._multiply_factors(result, factors[i])
        return result

    def get_analysis_text(self, query_str: str, answer: float) -> str:
        """生成自然语言分析报告（用于 prompt 注入）"""
        lines = ["--- Bayesian Network Exact Inference ---"]
        lines.append(f"Query: {query_str}")
        lines.append(f"Method: Variable elimination on the given Bayesian network")
        lines.append(f"Computed probability: {answer:.6f}")
        lines.append(f"As percentage: {answer*100:.2f}%")
        lines.append("--- End of Analysis ---")
        return "\n".join(lines)


def solve_blind_example(context: str, query: str, graph: str) -> Optional[float]:
    """便捷函数：解析并求解一个 BLInD 例题"""
    solver = BNSolver()
    solver.parse_graph(graph)
    solver.parse_cpt(context)
    return solver.solve(query)

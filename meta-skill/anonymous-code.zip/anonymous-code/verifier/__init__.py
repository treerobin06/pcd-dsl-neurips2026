"""4-Gate Verifier"""
